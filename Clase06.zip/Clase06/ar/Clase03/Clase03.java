package ar.Clase03;
   
public class Clase03 {

    public static void main(String[] args) {
        
 
    System.out.println("Adrian");

    //OPERADORES RELACIONALES
   
    boolean log1 = true;
    boolean log2 = false;   
    int nro1 = 5;
    int nro2 = 10;
    
    System.out.println(nro1<nro2);          //true
    System.out.println(nro1<=nro2);         //true
    System.out.println(nro1>nro2);          //false
    System.out.println(nro1>=nro2);         //false
    System.out.println(nro1==nro2);         //false
    System.out.println(nro1!=nro2);         //false

    System.out.println(nro1+5<nro2);        //false
    System.out.println(nro1+5*2<nro2*2+1);  //true
    System.out.println(nro1+5*2<nro2*2+1);  //true

    System.out.println(log1);               //true
    System.out.println(!log1);              //false
    System.out.println(!!log1);             //true
    System.out.println(!!!log1);            //false
    System.out.println(!!!!log1);           //true







    //TODO OPERADORES LOGICOS
    /*
     *  operadores logicos      nombre
     *  &&                      AND Y
     *  ||                      OR  O
     */

    //TODO TABLA DE VERDAD
    /*
            X   Y      OR      AND
            F   F      F        F
            F   V      V        F
            V   F      V        F
            V   V      V        V
    */      

    System.out.println(log1 || log2);       //true 
    System.out.println(log1 && log2);       //false
    
    
    //todo operador binarios &|
    System.out.println(log1 | log2);       //true
    System.out.println(log1 & log2);       //false

    //todo expresiones logicos
    



    }
}