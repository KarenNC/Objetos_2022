package ar.org.centro8.curso.java.test;

import javax.sound.sampled.SourceDataLine;
import ar.org.centro8.curso.java.utils.Calculadora;
import ar.org.centro8.curso.java.utils.ColoresAnsi;

public class TestCalculadora {
    /** Objetos Mock- objetos simulados */
   private static final Calculadora calcu1 = new Calculadora();
    public static void main(String[] args) {
        sumar();
        restar();
        multiplicar();
        dividir();        

    }

    private static void dividir() {
        //TODO test dividir
        System.out.println("Método dividir");
        if(true){
            System.out.println(ColoresAnsi.ANSI_GREEN + "OK" + ColoresAnsi.ANSI_RESET);}

        }    

    private static void multiplicar() {
        //TODO test multiplicar
        System.out.println("Método multiplicar");
    }

    private static void restar() {
        //TODO test restar
       
        double resultado=calcu1.restar(0, 0);
        Espacio("restar");
        System.out.println(resultado);
        if (resultado == 0) {
            System.out.println(ColoresAnsi.ANSI_GREEN + "OK" + ColoresAnsi.ANSI_RESET);}
        else  System.out.println(ColoresAnsi.ANSI_RED + "ERROR" + ColoresAnsi.ANSI_RESET);

        resultado=calcu1.sumar(2, 2);
        System.out.println("");
        System.out.println(resultado);
        if (resultado == 0) {
            System.out.println(ColoresAnsi.ANSI_GREEN + "OK" + ColoresAnsi.ANSI_RESET);}
        else  System.out.println(ColoresAnsi.ANSI_RED + "ERROR" + ColoresAnsi.ANSI_RESET);

        resultado=calcu1.sumar(10, -10);
        System.out.println("");
        System.out.println(resultado);
        if (resultado == 10) {
            System.out.println(ColoresAnsi.ANSI_GREEN + "OK" + ColoresAnsi.ANSI_RESET);}
        else  System.out.println(ColoresAnsi.ANSI_RED + "ERROR" + ColoresAnsi.ANSI_RESET);

        resultado=calcu1.sumar(-10, -10);
        System.out.println("");
        System.out.println(resultado);
        if (resultado == -20) {
            System.out.println(ColoresAnsi.ANSI_GREEN + "OK" + ColoresAnsi.ANSI_RESET);}
        else  System.out.println(ColoresAnsi.ANSI_RED + "ERROR" + ColoresAnsi.ANSI_RESET);

        resultado=calcu1.sumar(2000000000, 2000000000);
        System.out.println("");
        System.out.println(resultado);
        if (resultado == 0) {
            System.out.println(ColoresAnsi.ANSI_GREEN + "OK" + ColoresAnsi.ANSI_RESET);}
        else  System.out.println(ColoresAnsi.ANSI_RED + "ERROR" + ColoresAnsi.ANSI_RESET);
    }

    private static void sumar() {
        
        //TODO test sumar
        double resultado=calcu1.sumar(0, 0);
        
        Espacio("sumar");
        System.out.println(resultado);
        if (resultado == 0) {
            System.out.println(ColoresAnsi.ANSI_GREEN + "OK" + ColoresAnsi.ANSI_RESET);}
        else  System.out.println(ColoresAnsi.ANSI_RED + "ERROR" + ColoresAnsi.ANSI_RESET);

        resultado=calcu1.sumar(2, 2);
        System.out.println("");
        System.out.println(resultado);
        if (resultado == 4) {
            System.out.println(ColoresAnsi.ANSI_GREEN + "OK" + ColoresAnsi.ANSI_RESET);}
        else  System.out.println(ColoresAnsi.ANSI_RED + "ERROR" + ColoresAnsi.ANSI_RESET);

        resultado=calcu1.sumar(10, -10);
        System.out.println("");
        System.out.println(resultado);
        if (resultado == 0) {
            System.out.println(ColoresAnsi.ANSI_GREEN + "OK" + ColoresAnsi.ANSI_RESET);}
        else  System.out.println(ColoresAnsi.ANSI_RED + "ERROR" + ColoresAnsi.ANSI_RESET);

        resultado=calcu1.sumar(-10, -10);
        System.out.println("");
        System.out.println(resultado);
        if (resultado == -20) {
            System.out.println(ColoresAnsi.ANSI_GREEN + "OK" + ColoresAnsi.ANSI_RESET);}
        else  System.out.println(ColoresAnsi.ANSI_RED + "ERROR" + ColoresAnsi.ANSI_RESET);

        resultado=calcu1.sumar(2000000000, 2000000000);
        System.out.println("");
        System.out.println(resultado);
        if (resultado == 0) {
            System.out.println(ColoresAnsi.ANSI_GREEN + "OK" + ColoresAnsi.ANSI_RESET);}
        else  System.out.println(ColoresAnsi.ANSI_RED + "ERROR" + ColoresAnsi.ANSI_RESET);

        //sumar 0+0=0
        //sumar 2+2=4
        //sumar 10-10=0
        //sumar -10-10=-20
        //sumar 20000000000000000000+200000000000000000
    }

    private static void Espacio(String nombre) {
        System.out.println("");
        System.out.println("*******************************************");
        System.out.println("Método "+nombre);
    }

    public static Calculadora getCalcu1() {
        return calcu1;
    }
}
