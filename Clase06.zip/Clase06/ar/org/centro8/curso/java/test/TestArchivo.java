package ar.org.centro8.curso.java.test;

/*
 * Los archivos .java pueden contener Clases Interfaces Enumerados.
 * Solo puede existir en el archivo un miembro publico,
 * el miembro de archivo que sea publico, debe tener el mismo nombre que la clase
 */

public class TestArchivo {}

class TestArchivo2{}

interface Archivo{}
enum dias{LUNES,MARTES,MIÉRCOLES,JUEVES,VIERNES}