public class Auto {
    // atributos
    String marca;
    String modelo;
    String color;
    int velocidad;

    // cuando se crea el constructor, java saca el constructor vacio
    @Deprecated // Annotation JDK 5 O sup, está obsoleto
    /**
     * Este método está deprecado por ser inseguro o incompleto. usar en su
     * reemplazo Auto(String marca, String modelo, String color)
     */
    Auto() {
    }// constructor vacio

    Auto(String marca, String modelo, String color) {// esto y los getters y setters los va a escribir el IDE
        this.marca = marca;
        this.modelo = modelo;
        this.color = color;
    }

    // metodos
    void acelerar() {
        velocidad += 10;
        if (velocidad > 100)
            velocidad = 100;
    }

    void frenar() {
        velocidad -= 10;
    }

    // método con parámetros de entrada
    void acelerar(int kilometros) {
        velocidad += kilometros;
        if (velocidad > 100)
            velocidad = 100;
    }

    void imprimirVelocidad() {
        System.out.println(velocidad);
    }

    int getVelocidad() {
        return velocidad;
    }

    @Override
    public String toString() {
        return this.marca + " " + this.modelo + " " + this.color + " " + this.velocidad;

    }
}
