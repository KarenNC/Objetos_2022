import javax.swing.JOptionPane;

public class Clase03 {
    public static void main(String[] args) {
        /*
         * Qué es una clase? representa ideas generales del mundo real, se detectan como
         * sustantivos.
         * una clase representa una plantilla
         * Ejemplo de clases: Alumno, Profesor,Computadora, Silla, Profesor
         * 
         * Los atributos son objetos de la clase java.lang.reflect.field
         * Los atributos en java se inicializan automaticamente al construir un objetos
         * Los atributos String se inicializan en null y los atributos numéricos se
         * inicializan en 0
         * la clas field representa a todos los atributos
         * Objeto: es una instancia en particular de una clase.
         * Tiene estado propio(tiene valor en sus atributos y es propio, no pertenece a
         * otro objeto.
         * 
         * Qué es un método? un método es una acción que realiza la clase. Puede tener
         * parámetros de entrada y salida.
         * Métodos en java: los métodos en java son objetos de la clase
         * java.lang.reflect.method
         * 
         * Sobrecarga de métodos: ocurre cuando dentro de una clase dos métodos tienen
         * el mismo nombre
         * Valor de retorno: es el valor retornado luego de la ejecucion de un metodo,
         * sino retorna el valor
         * el método es void. El valor de un retorno tiene un tipo de datos asociado
         * valor de retorno:
         * Métodos constructores en java: son objetos de la clase
         * java.lang.reflect.constructor
         * metodos constructores: son metodos que inicializan un objeto. no tiene
         * devolucion de valor,tienen el mismo nombre que la clase
         * si la clase no tiene constructor se ejecuta automaticamente
         * si la clase no tiene constructro java agrega un constructor vacio al compilar
         * 
         * metodo toString:
         */
        System.out.println("auto1");
        Auto auto1 = new Auto();
        System.out.println(auto1.marca + " " + auto1.modelo + " " + auto1.color + " " + auto1.velocidad);
        // int x;
        // System.out.println(x); debe ser inicializada antes de imprimir
        auto1.color = "negro";
        auto1.marca = "Ford";
        auto1.modelo = "K";

        auto1.acelerar();
        auto1.acelerar();
        auto1.frenar();
        auto1.acelerar();
        System.out.println(auto1.velocidad);

        System.out.println(auto1.marca + " " + auto1.modelo + " " + auto1.color + " " + auto1.velocidad);
        System.out.println("auto2");
        Auto auto2 = new Auto();
        auto2.marca = "Fiat";
        auto2.color = "gris";
        auto2.modelo = "Idea";

        for (int a = 0; a <= 50; a++) {
            auto2.acelerar();
        }

        auto1.acelerar(25);
        System.out.println(auto1.velocidad);

        auto2.imprimirVelocidad();// no se utiliza ya que necesito enviar el dato, no imprimirlo
        auto2.getVelocidad();

        JOptionPane.showMessageDialog(null, "Hola a todos");
        JOptionPane.showMessageDialog(null, "velocidad: " + auto2.getVelocidad());
        // metodo toString:
        System.out.println(auto1.toString());
        System.out.println(auto1);// se invoca automaticamente el toString

        // TODO: ARQUITECTURA DEL PROYECTO
        // TODO: visibilidad Setters y Getters
    }
}
