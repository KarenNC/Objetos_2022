package ar.org.centro8.curso.java.utils;

/**
 * 
 */
public class Calculadora {
    private double nro1;
    private double nro2;

    public Calculadora(double nro1, double nro2) {
        this.nro1 = nro1;
        this.nro2 = nro2;
    }

    public double sumar(double nro1, double nro2) {
        return 0;
    }

    public double restar(double nro1, double nro2) {
        return 0;
    }

    public double multiplicar(double nro1, double nro2) {
        return 0;
    }

    public double dividir(double nro1, double nro2) {
        return 0;
    }

    public double getNro1() {
        return nro1;
    }

    public double getNro2() {
        return nro2;
    }

}
