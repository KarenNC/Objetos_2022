package ar.org.centro8.curso.java.test;

import javax.sound.sampled.SourceDataLine;

import ar.org.centro8.curso.java.utils.Calculadora;
import ar.org.centro8.curso.java.utils.ColoresAnsi;

public class TestCalculadora {
    /** Objetos simulados */
    public static void main(String[] args) {
        Calculadora calcu1 = new Calculadora(2, 4);

        if (calcu1.getNro1() == 2) {
            System.out.println(ColoresAnsi.ANSI_GREEN + "OK" + ColoresAnsi.ANSI_RESET);
        } else {
            System.out.println(ColoresAnsi.ANSI_RED + "error" + ColoresAnsi.ANSI_RESET);
        }
        if (calcu1.getNro2() == 4) {
            System.out.println(ColoresAnsi.ANSI_GREEN + "OK" + ColoresAnsi.ANSI_RESET);
        } else {
            System.out.println(ColoresAnsi.ANSI_RED + "error" + ColoresAnsi.ANSI_RESET);
        }

    }
}
