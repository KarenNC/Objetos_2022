import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;
import java.util.TreeSet;

import javax.sound.sampled.SourceDataLine;

public class TestCollections {
    public static void main(String[] args) {
        Auto[] autos = new Auto[4];
        Auto auto1 = new Auto("f", "g", "h");
        Auto auto2 = new Auto("among", "us", "sus");

        // for(int a=0;a=autos.length;a++)
        // {System.out.println(auto1);}

        // recorrido usando forEach
        for (Auto auto : autos)
            System.out.println(auto);

        // interface list
        List lista1 = new ArrayList<>();
        lista1.add(auto1);
        lista1.add(auto2);
        lista1.add("hola");
        lista1.add("chau");
        lista1.add(22);
        lista1.add(3, "si");

        System.out.println(lista1);

        // metodoforeach java8 o superior
        // lista1.forEach(o -> System.out.println("sus" + o));
        // lista1.forEach(o -> {System.out.println("sus" + o);});
        lista1.forEach(System.out::println);

        // uso de generics
        List<Auto> lista2 = new ArrayList();
        lista2.add(new Auto("m", "a", "g"));

        // convertir vector en una lista: List.of()

        // videos de este tema desde 126 137

        // consecuencia de intereface set no permite elementos duplicados

        // Interface set no hay indice ni duplicados
        Set<String> set;

        // set = new HashSet<>();// es mas veloz pero no garantiza el orden de los
        // elementos
        // implementacion linkedhashset no es lo mas veloz pero lo almacena por orden de
        // ingreso
        // set = new LinkedHashSet<>();

        set = new TreeSet<>();// lo ordena por orden natural
        set.add("Lunes");
        set.add("Lunes");// no lo va a ingresar
        set.add("Martes");
        set.add("Miercoles");
        set.add("Jueves");
        set.add("Viernes");

        set.forEach(System.out::println);

    }
}
