package ar.org.centro8.curso.java.utils;

public class Calculadora {

    /**
     * Suma los dos números ingresados en los parámetros de entrada.
     * @param nro1  número 1
     * @param nro2  número 2
     * @return  resultado de la operación
     */
    public double sumar(double nro1, double nro2) {
        return nro1+nro2;
    }

    /**
     * Resta los dos números ingresados en los parámetros de entrada.
     * @param nro1  número 1
     * @param nro2  número 2
     * @return  resultado de la operación
     */
    public double restar(double nro1, double nro2) {
        return nro1-nro2;
    }

    /**
     * Multiplica los dos números ingresados en los parámetros de entrada.
     * @param nro1  número 1
     * @param nro2  número 2
     * @return  resultado de la operación
     */
    public double multiplicar(double nro1, double nro2) {
        return nro1*nro2;
    }

    /**
     * Divide los dos números ingresados en los parámetros de entrada.
     * En caso de división /0 imprime el cartel ArithmeticException
     * @param nro1  número 1
     * @param nro2  número 2
     * @return  resultado de la operación
     */
    public double dividir(double nro1, double nro2) {
        //if(nro2==0) throw new ArithmeticException();
        if(nro2==0) System.out.println("Error no se puede dividir /0");
        return nro1/nro2;
    }
}
