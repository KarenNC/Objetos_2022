package ar.org.centro8.curso.java.entities;

public class TestVulneravilidad {
    public static void main(String[] args) {
        Cuenta cuenta=new Cuenta(1, "arg4");
        //cuenta.saldo=99999999;
    }
}
