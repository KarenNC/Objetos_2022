package ar.org.centro8.curso.java.entities;

public class Direccion {
    String calle;
    int numero;
    String piso;
    String depto;
    String ciudad;

    /**CONSTRUCTOR PARA DIRECCIONES DE CIUDAD AUTÓNOMA DE BUENOS AIRES */
    public Direccion(String calle, int numero, String piso, String depto) {
        this.calle = calle;
        this.numero = numero;
        this.piso = piso;
        this.depto = depto;
        this.ciudad="CABA";
    }


    public Direccion(String calle, int numero, String piso, String depto, String ciudad) {
        this.calle = calle;
        this.numero = numero;
        this.piso = piso;
        this.depto = depto;
        this.ciudad = ciudad;
    }


    public String getCalle() {
        return calle;
    }


    public int getNumero() {
        return numero;
    }


    public String getPiso() {
        return piso;
    }


    public String getDepto() {
        return depto;
    }


    public String getCiudad() {
        return ciudad;
    }


    public void setCalle(String calle) {
        this.calle = calle;
    }


    public void setNumero(int numero) {
        this.numero = numero;
    }


    public void setPiso(String piso) {
        this.piso = piso;
    }


    public void setDepto(String depto) {
        this.depto = depto;
    }


    public void setCiudad(String ciudad) {
        this.ciudad = ciudad;
    }


    @Override
    public String toString() {
        return "Direccion [calle=" + calle + ", ciudad=" + ciudad + ", depto=" + depto + ", numero=" + numero
                + ", piso=" + piso + "]";
    }

    
}
