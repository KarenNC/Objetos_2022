package ar.org.centro8.curso.java.entities;
//abstract: no podemos crear objetos con esta clase, no se ouede crear un new persona
//lo contrario es final, me permite crear los objetos de una clase
//no puedo crear una clase hija con final
public abstract class Persona {
    private String nombre;
    private int edad;
    private Direccion direccion;

    public Persona(String nombre, int i, Direccion direccion1) {
        this.nombre = nombre;
        this.edad = i;
        this.direccion = direccion1;
        
    }
    
    @Override
    public String toString() {
        return "Persona [direccion=" + direccion + ", edad=" + edad + ", nombre=" + nombre + "]";
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public Direccion getDireccion() {
        return direccion;
    }

    public void setDireccion(Direccion direccion) {
        this.direccion = direccion;
    }

    public abstract void saludar();
    
}
