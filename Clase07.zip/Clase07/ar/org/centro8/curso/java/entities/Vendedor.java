package ar.org.centro8.curso.java.entities;
import ar.org.centro8.curso.java.entities.Persona;
public class Vendedor extends Persona {

    private int nrolegajo;
    private double sueldobasico;
    public Vendedor(String nombre, int i, Direccion direccion1, int nrolegajo, double sueldobasico) {
        super(nombre, i, direccion1);
        this.nrolegajo = nrolegajo;
        this.sueldobasico = sueldobasico;
    }
@Override
public void saludar(){
    System.out.println("Hola soy un vendedor");

    
}
public int getNrolegajo() {
    return nrolegajo;
}
public void setNrolegajo(int nrolegajo) {
    this.nrolegajo = nrolegajo;
}
public double getSueldobasico() {
    return sueldobasico;
}
public void setSueldobasico(double sueldobasico) {
    this.sueldobasico = sueldobasico;
}
    
 @Override
    public String toString() {
        // TODO Auto-generated method stub
        return super.toString();
    }


}    

