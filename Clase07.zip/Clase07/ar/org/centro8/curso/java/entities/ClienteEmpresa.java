package ar.org.centro8.curso.java.entities;

import java.lang.reflect.Array;
import java.util.ArrayList;
import ar.org.centro8.curso.java.entities.Cuenta;


public class ClienteEmpresa {
    private int nro;
    
    public void setNro(int nro) {
        this.nro = nro;
    }

    public void setRazonSocial(String razonSocial) {
        this.razonSocial = razonSocial;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    public int getNro() {
        return nro;
    }

    public String getRazonSocial() {
        return razonSocial;
    }

    private String razonSocial;

    private String direccion;
    public String getDireccion() {
        return direccion;
    }

    //private cuenta[] cuentas=new Cuenta[10000];
    private ArrayList <Cuenta> cuentas= new ArrayList();
    
    public ClienteEmpresa(int nro, String razonSocial, ArrayList<Cuenta> cuentas) {
        this.nro = nro;
        this.razonSocial = razonSocial;
        this.cuentas = cuentas;
    }

       
    

}
