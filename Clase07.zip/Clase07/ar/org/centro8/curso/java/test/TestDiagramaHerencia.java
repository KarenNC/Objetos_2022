package ar.org.centro8.curso.java.test;
import ar.org.centro8.curso.java.entities.ClientePersona;
import ar.org.centro8.curso.java.entities.Direccion;
import ar.org.centro8.curso.java.entities.Vendedor;
public class TestDiagramaHerencia {
        public static void main(String[] args) {

            System.out.println("******dir1*****");
            Direccion direccion1=new Direccion("Medrano",162,"1","1");
            System.out.println(direccion1);


            System.out.println("******dir2*****");
            Direccion direccion2=new Direccion("Belgrano",1456,null,null,"Moron");
            System.out.println(direccion2);
            
            System.out.println("*vendedor*");
            Vendedor vendedor1=new Vendedor("Lorena",44,direccion1,1,250000);
            vendedor1.saludar();

            ClientePersona cliente=new ClientePersona(nro, nombre, edad)
        
        }


    }

