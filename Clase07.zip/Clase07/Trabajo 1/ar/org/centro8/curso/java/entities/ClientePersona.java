package ar.org.centro8.curso.java.entities;

public class ClientePersona {
    private int nro;
    private String nombre;
    private int edad;
    private Cuenta cuenta;

    //constructores
    //Un cliente puede ser creado sin una cuenta.
    public ClientePersona(int nro, String nombre, int edad){
        this.nro=nro;
        this.nombre=nombre;
        this.edad=edad;
    }

    //El cliente siempre tiene una cuenta
    //La cuenta puede pertenecer a otro cliente
    //Una cuenta puede pertenecer a más de un cliente
    public ClientePersona(int nro, String nombre, int edad, Cuenta cuenta){
        this.nro=nro;
        this.nombre=nombre;
        this.edad=edad;
        this.cuenta=cuenta;
    }

    //El cliente siempre tiene una cuenta
    //dicha cuenta cuenta es propia del cliente, se le crea para el.
    public ClientePersona(int nro, String nombre, int edad, int nroCuenta){
        this.nro=nro;
        this.nombre=nombre;
        this.edad=edad;
        this.cuenta=new Cuenta(nroCuenta,"arg$");
    }

    @Override
    public String toString() {
        return "ClientePersona [cuenta=" + cuenta + ", edad=" + edad + ", nombre=" + nombre + ", nro=" + nro + "]";
    }

    public int getNro() {
        return nro;
    }

    public void setNro(int nro) {
        this.nro = nro;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getEdad() {
        return edad;
    }

    public void setEdad(int edad) {
        this.edad = edad;
    }

    public Cuenta getCuenta() {
        return cuenta;
    }

    public void setCuenta(Cuenta cuenta) {
        this.cuenta = cuenta;
    }

}
