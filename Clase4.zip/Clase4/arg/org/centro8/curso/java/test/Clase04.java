package arg.org.centro8.curso.java.documents;
public class Clase04 {
//Arquitectura del proyecto
    public static void main(String[] args) {
        System.out.println("Hola Mundo");
    }
}
